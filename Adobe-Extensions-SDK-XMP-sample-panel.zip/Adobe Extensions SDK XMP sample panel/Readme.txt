=================================================================================================
ADOBE SYSTEMS INCORPORATED
 Copyright 2014 Adobe Systems Incorporated
 All Rights Reserved.

NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the 
terms of the Adobe license agreement accompanying it.  If you have received this file from a 
source other than Adobe, then your use, modification, or distribution of it requires the prior 
written permission of Adobe.
=================================================================================================

Adobe Extensions SDK XMP sample panel

1. About
This sample illustrates how to create an HTML5 panel with Adobe's Extensions SDK 
that allows a user of Adobe's Creative Cloud applications to interact with an asset's XMP.

To learn more about HTML5 extensions please see this link:
http://blogs.adobe.com/cssdk/
The sample code also contains a lot of in-line documentation that should be read to understand
the sample.


2. Compatibility
The panel runs in Photoshop CC, Illustrator CC, Indesign CC and Premiere Pro CC 2014


3. Installation

* Install Extension Manager CC from Creative Cloud

* Install latest Adobe's Extension Builder plug-in for Eclipse:
	http://labs.adobe.com/technologies/extensionbuilder3/

* Switch to the Extension Builder perspective within Eclipse and import the existing project 
	from the sample directory.

* Right-click the project in Eclipse and choose Export > Adobe Extension Builder/Application Extension

* After the export install the extension with Adobe Extension Manager CC


4. Usage

* Start one of the compatible Creative Cloud applications and open an asset

* invoke the panel through the extension menu, e.g. Photoshop CC: Window > Extensions > XmpSamplePanel
